﻿//-----------------------------------------------------------------------------
// <copyright file="MailValidator.cs" company="PayVision">
//     Copyright ® PayVision 2016
// </copyright>
//-----------------------------------------------------------------------------
namespace FraudPrevention.Business
{
    using System;
    using System.Collections.Generic;
    using DomainModel;
    using Interfaces;

    public class MailValidator : IValidator
    {
        public IList<int> GetFraudulentOrders(IEnumerable<Order> orders)
        {
            // It will Regular expression to separate username part
            //To capitalize to avoid case sensitive issue
            // and a regular expression pattern to solve A. and A+ cases.
            // Reg Exp patterns will be loaded by config.
            throw new NotImplementedException();
        }
    }
}
