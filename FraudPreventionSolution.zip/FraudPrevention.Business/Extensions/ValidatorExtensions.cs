﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FraudPrevention.Interfaces;

namespace FraudPrevention.Business.Extensions
{
    public static class ValidatorExtensions
    {
        public static string ToCapitalize(this string validatorField)
        {
            return validatorField.ToUpper();
        }
    }
}
